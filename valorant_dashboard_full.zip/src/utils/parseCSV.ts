import Papa from "papaparse";

export async function loadCSVData(url: string): Promise<any[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(url, {
      download: true,
      header: true,
      dynamicTyping: true,
      complete: (results) => resolve(results.data as any[]),
      error: reject,
    });
  });
}
