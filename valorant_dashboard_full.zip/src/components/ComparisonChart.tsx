import Plot from "react-plotly.js";

export function ComparisonChart({ data, xKey, yKeys }) {
  const traces = yKeys.map(key => ({
    x: data.map(d => d[xKey]),
    y: data.map(d => d[key]),
    type: 'bar',
    name: key
  }));

  return (
    <Plot
      data={traces}
      layout={{ barmode: 'group', title: 'Comparison Graph' }}
      style={{ width: "100%", height: "400px" }}
    />
  );
}
