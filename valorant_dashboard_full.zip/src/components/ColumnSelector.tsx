export function ColumnSelector({ allColumns, visibleColumns, setVisibleColumns }) {
  return (
    <div className="flex flex-wrap gap-2 p-2">
      {allColumns.map(col => (
        <label key={col}>
          <input
            type="checkbox"
            checked={visibleColumns.includes(col)}
            onChange={() => {
              setVisibleColumns(cols =>
                cols.includes(col)
                  ? cols.filter(c => c !== col)
                  : [...cols, col]
              );
            }}
          />{" "}
          {col}
        </label>
      ))}
    </div>
  );
}
