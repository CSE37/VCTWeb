import { useEffect, useState } from "react";
import { loadCSVData } from "./utils/parseCSV";
import { DataTable } from "./components/DataTable";
import { ColumnSelector } from "./components/ColumnSelector";
import { ComparisonChart } from "./components/ComparisonChart";

function App() {
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [visibleColumns, setVisibleColumns] = useState([]);
  const [grouping, setGrouping] = useState(["Year"]);
  const [selectedMetrics, setSelectedMetrics] = useState(["ACS", "KAST"]);
  const [filters, setFilters] = useState({});

  useEffect(() => {
    loadCSVData("/all_data.csv").then(csv => {
      setData(csv);
      const allKeys = Object.keys(csv[0] || {});
      setColumns(allKeys);
      setVisibleColumns(allKeys);
    });
  }, []);

  const filteredData = data.filter(row =>
    Object.entries(filters).every(([key, val]) =>
      val.length ? val.includes(row[key]) : true
    )
  );

  const tableCols = visibleColumns.map(col => ({
    accessorKey: col,
    header: col,
  }));

  const filterKeys = ["Year", "Event", "Region", "Org"];

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-bold">Valorant Stats Dashboard</h1>
      <ColumnSelector allColumns={columns} visibleColumns={visibleColumns} setVisibleColumns={setVisibleColumns} />
      <div className="space-y-2">
        {filterKeys.map(key => (
          <div key={key}>
            <label className="mr-2">{key}:</label>
            <select multiple className="border p-1" onChange={e => {
              const options = Array.from(e.target.selectedOptions).map(o => o.value);
              setFilters(prev => ({ ...prev, [key]: options }));
            }}>
              {[...new Set(data.map(d => d[key]))].map(val => (
                <option key={val} value={val}>{val}</option>
              ))}
            </select>
          </div>
        ))}
        <label className="block mt-2">Group by:</label>
        <select onChange={e => setGrouping([e.target.value])}>
          {filterKeys.map(key => (
            <option key={key} value={key}>{key}</option>
          ))}
        </select>
      </div>
      <DataTable data={filteredData} columns={tableCols} grouping={grouping} setGrouping={setGrouping} />
      <h2 className="text-lg font-semibold mt-6">Comparison Graph</h2>
      <ComparisonChart data={filteredData} xKey={grouping[0]} yKeys={selectedMetrics} />
    </div>
  );
}

export default App;
